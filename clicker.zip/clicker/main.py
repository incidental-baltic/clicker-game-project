import tkinter as tk
import random
import Dictionaries as Dc
import pickle as Pk


#the base data for the roulette system
#saves payouts,checks and bet amounts
roulette_options = {
    'green': {'payout': 36, 'check': lambda x: x==0},
    'red': {'payout': 2, 'check': lambda x: x%2 == 1},
    'black': {'payout': 2, 'check': lambda x: x!=0 and(x+1)%2 ==1},
    'bet_amount':10
}

#list of menus for each world
world_1_menus = ["Clicker","Shop","Stats_page","the casino"]
world_2_menus = ["A_clicker"]
#constant needed for realm
realm_base_threshold = 10**7
index_power_increment = 0.5

#time constants for how often a function happens in milliseconds so divide by 1000 to get in seconds
universal_delay = 1000
income_check_delay = 2500
capitalist_duration = 10000
dollar_spawn_interval = 120000

#constants for ascension and research for upgrades
max_upgrade_level = 10
research_mpc_multiplier = 0.1
research_mps_multiplier = 0.1
ascension_mps_multiplier = 0.2
ascension_mpc_multiplier = 0.2

#list of money requirements for the money achievements
money_achievements = [10**6,10**20,10**100]

#base values needed for calculating price of upgrades in the shop
Shop_cost_multiplier = 1.25
mpc_base_cost = 15
mps_base_cost = 100

#boost given during the 'capitalist' buff after clicking on a dollar or the crystal boost when exchanging crystals
capitalist_boost = 7
crystal_boost = 3

count=0
global gambcount;gambcount=0
global toggle
toggle = True
widgets = {}

#2function to save and load progress in a file
def save_to_file():

    to_export = []
    #list to hold all of the data saved to the file

    for a in vars(Dc).values():
    #loops for every value stored in the dictionaries file - shortened to Dc on line 3
    #example - "levels" = [1,2,3] so a = [1,2,3]

        if isinstance(a,list) or isinstance(a,int):
        #this line checks whether the value is a list or an integer. 
        #all dictionary values in the dictionary file are either integer values or lists

            to_export.append(a)
            #this adds the current value into the list of things to export

        elif isinstance(a,dict):
        #if the value is neither as list or an integer its most likely a dictionary

            try:
                if a['__name__'] == 'builtins':
                    pass
            #this set of 3 lines checks whether the value is a python internal system
            #we only need to save the variable data from the dictionary file not pythons internals
            #thus we skip it

            except Exception:
                to_export.append(a)
            #if it finds out that the dictionary is not one of pythons internals then it adds it to the list to be exported

    Pk.dump(to_export,open("data.bin","wb"))
    #simply opens the data bin file
    #then writes everything in the export list in binary


def load_from_file():
    to_import = Pk.load(open("data.bin","rb"))
    #this opens the file data bin
    #then it reads everything in binary
    #this transfers the binary we turned it into back into normal data

    c = 0
    #this is a counter to track which saved value we are changing

    for name, a in vars(Dc).items():
    #this loops through every item in the dictionaries file taking the name and values inside

        if isinstance(a,list) or isinstance(a,int):
        #this again checks for lists or integer values

            vars(Dc)[name] = to_import[c]
            #this replaces the current value with the stored value in c
            
            c += 1
            #this moves the c value up to match with the next value needing to be changed

        elif isinstance(a,dict):
        #checks for dictionaries again

            try:
                if a['__name__'] == 'builtins':
                    pass
            #makes sure the value isnt a python internal again

            except Exception:
                vars(Dc)[name] = to_import[c]
                c += 1
                #replaces all dictionary values with c


#function to count how long you have been playing for. hours|minutes|seconds format
def time_count():
    Dc.time['seconds']+=1
    #after 1 iteration of this function seconds increases by 1
    if Dc.time['seconds']==60:
        Dc.time['seconds']=0;Dc.time['minutes']+=1
    #if seconds reaches 60, seconds resets and minutes increases by one
    if Dc.time['minutes']==60:
        Dc.time['hours']+=1;Dc.time['minutes']=0
    #if minutes reaches 60, minutes reset and hours increases by 1
    #function runs every 1 second so its perfectly synced

#the window in which the game runs on.
window = tk.Tk()
#the dimensions for which the game is intended to run on. 
#if you manually change it, dont be surprised to see cut off points
window.geometry("1000x1000")

#function to recalculate how much money you should be getting per click or per second. updates every time mpc or mps should change
def recalculate_mpc_mps(n):

    #checks if the recalculation is for the money per second or money per click
    #calculates how the values of (base money per click/second - the multiplier from upgrades - multiplier from research and ascension - index) all work together
    if n == 'mpc':
        Dc.money_per_click['mpc']= ((Dc.money_per_click['mpc_count'] * Dc.money_per_click['mpc_multiplier'])**Dc.realms['mpc_power'])*((1+(research_mpc_multiplier*Dc.research['research_mpc_upgrade']))*(1+(ascension_mpc_multiplier*Dc.ascension['ascension_mpc_upgrade']))*((Dc.research['research_points']/100)+1)*((Dc.ascension['ascension_points'])+1))
    if n == 'mps':
        Dc.money_per_second['mps']= ((Dc.money_per_second['mps_count'] * Dc.money_per_second['mps_multiplier'])**Dc.realms['mps_power'])*((1+(research_mps_multiplier*Dc.research['research_mps_upgrade']))*(1+(ascension_mps_multiplier*Dc.ascension['ascension_mps_upgrade']))*((Dc.research['research_points']/100)+1)*((Dc.ascension['ascension_points'])+1))

#function to format money. 
#if money reaches larger than 1 million display changes
#display changes to AeB form
def format_money(value):
    if value < 1e6:
        return (str(int(value)))
    return "{:.2e}".format(value)


#function that will alter whether the stats bar is visible or not
def action():
    global toggle
    
    #the toggle is based that if the toggle is true, then stats is hidden
    if(toggle):
        widgets['frame'].place(x=0,y=0)
        toggle = False
        stats_page_dict['button'].place(x=200,y=490)
        widgets['label'].update()
    else:
        widgets['frame'].place(x=-400,y=0)
        toggle = True
        stats_page_dict['button'].place(x=0,y=490)


#function that will deal with buying money per clicks
def buying_mpc():
    if Dc.money['money']>= Dc.money_per_click['mpc_cost']:
        Dc.money['money']-=Dc.money_per_click['mpc_cost']
        Dc.money_per_click['mpc_count']+=1
    #does the initial purchase. 
    #checks if the player has enough money and if so, subtracts the cost from current money
    #finally it adds 1 to the base money per click
    update_money_widget()
    #money changes due to reduction so update the money widget
    Dc.money_per_click['mpc_cost'] = int(15*(Shop_cost_multiplier**(Dc.money_per_click['mpc_count']-1)))
    #redefines the cost as the cost increases with each subsequent purchase
    if len(str(int(Dc.money_per_click['mpc_cost'])))> 6:
        Shop_dict['mpc_cost'].configure(text=f"you have {Dc.money_per_click['mpc_count']} shop mpc \n this current upgrade will cost {format_money(Dc.money_per_click['mpc_cost'])}")
        Shop_dict['mpc_cost'].update()
    else:    
        Shop_dict['mpc_cost'].configure(text=f"you have {Dc.money_per_click['mpc_count']} shop mpc \n this current upgrade will cost {int(Dc.money_per_click['mpc_cost'])}")
        Shop_dict['mpc_cost'].update()
    #basic formatting line
    #if the money if larger than 1 million, it formats it to e form.
    recalculate_mpc_mps('mpc')
    #recalculates money per click since it has increased
    upgrade_check()
    #due to base money per click stacks increasing, it checks if it has reached one of the boundaries for an upgrade to appear

def update_money_widget():
    display = format_money(Dc.money['money'])
    clicker_dict['money'].configure(text=display)
    Shop_dict['shop money'].configure(text=f"you have {display} to spend")
    clicker_dict['money'].update()
    Shop_dict['shop money'].update()
    #changes the display money to the formatted amount
    #updates the clicker menu and shop menu amounts.

#function that deals with manual money gain
#boosts are given based on if certain events like the capitalist or crystal boost event are on
def money_gain(m):
    total_multiplier = 1
    if Dc.events['crystal_boost'] == True:
        total_multiplier *= crystal_boost
    if Dc.events['capitalist'] == True:
        total_multiplier*= capitalist_boost
    #uses a total multiplier to see how the boosts stack up
    #use 1 if statement for each boost rather than manually checking each outcome
    Dc.money['money'] += m * total_multiplier
    Dc.money['total_money_made'] += m * total_multiplier 
    #self explanatory
    if Dc.money['money'] > Dc.money['peak_money']:
        Dc.money['peak_money'] = Dc.money['money']
        #self explanatory
    update_money_widget()
    stats_page_dict['label'].configure(
        text = f"Statistics:\nhighest money = {format_money(Dc.money['peak_money'])}\ntotal money = {format_money(Dc.money['total_money_made'])}\nmoney per second ={format_money(Dc.money_per_second['mps'])}\nmoney per click = {format_money(Dc.money_per_click['mpc'])}\ntime={Dc.time['hours']}:{Dc.time['minutes']}:{Dc.time['seconds']}\n achievements completed = {Dc.achievements}"
    )
    #updates the stats page and the money widget since money changed from increase
    
    stats_page_dict['label'].update()
    #update label


#function to loop the automatic money gain
def loop_amoney():
    money_gain(Dc.money_per_second['mps'])
    #every second you gain money based on your current money per second
    #does not account for boosts


#function to deal with buying money per second
def buying_mps():
    if Dc.money['money']>= Dc.money_per_second['mps_cost']:
        Dc.money['money']-=Dc.money_per_second['mps_cost']
        Dc.money_per_second['mps_count']+=1
        #calculates exhange, is money higher than cost. if so money-cost
        #after you get charged for the upgrade, your base mps increases by 1
    update_money_widget()
    #updates money widget since money decreased
    Dc.money_per_second['mps_cost'] = int(100*(Shop_cost_multiplier**(Dc.money_per_second['mps_count'])))
    #updates cost since each consequetive purchase increases the price 
    if len(str(int(Dc.money_per_second['mps_cost'])))> 6:
        Shop_dict['mps_cost'].configure(text=f"you have {Dc.money_per_second['mps_count']} shop mps \n this current upgrade will cost {format_money(Dc.money_per_second['mps_cost'])}")
        Shop_dict['mps_cost'].update()
    else:    
        Shop_dict['mps_cost'].configure(text=f"you have {Dc.money_per_second['mps_count']} shop mps \n this current upgrade will cost {int(Dc.money_per_second['mps_cost'])}")
        Shop_dict['mps_cost'].update()
        #basic formatting line
    #if the money if larger than 1 million, it formats it to e form.
    recalculate_mpc_mps('mps')
    #recalculates money per second since base mps increased
    upgrade_check()
    #checks if any upgrade parameters have been passed since base mps has been increased


#functions to deal with the dollar boost/ temporary 7x boost in money gain
def stop_capitalist():
    Dc.events['capitalist']=False
    #once this function is called, the capitalist boost will be inactive

def activate_capitalist_boost():
    widgets["DOLLA"].place(x=-300,y=-3000)
    Dc.events['capitalist']=True 
    window.after(capitalist_duration,stop_capitalist)
    #this "removes" the dollar by placing it in an unreachable position.
    #afterwards it activates the capitalist boost
    #it calls the stop_capitalist function after the duration of the boost of over to deactivate the boost

def spawn_dolla():
    window.after(dollar_spawn_interval,spawn_dolla)
    Dc.events['dollar_count']+=1
    if Dc.events['dollar_count']>=2:widgets["DOLLA"].place(x=random.randrange(1,800),y=random.randrange(1,915))
    #after every interval, it will add 1 to the dollar count
    #if during the function the count is later than 1, it will place a dollar somewhere on the screen.
    #this function calls itself every 2 minutes

#function to add in income counter
def income_check():
    temp_money_2=Dc.money['money']
    #takes a snapshot of what the money is at the start of the function
    Dc.money['income']=int((temp_money_2-Dc.money['temp_money_1'])/(income_check_delay / 1000))
    #income = current-old money / time 
    #checks how much money changes in 1 check
    if len(str(int(Dc.money['income']))) > 6:
        clicker_dict['income'].configure(text=f"current average money per second is {format_money(Dc.money['income'])}")
        clicker_dict['income'].update()
    else:
        clicker_dict['income'].configure(text=f"current average money per second is {int(Dc.money['income'])}")
        clicker_dict['income'].update()
    #basic formatting line
    #if the money if larger than 1 million, it formats it to e form.
    Dc.money['temp_money_1']=temp_money_2
    #sets the new "old" money as the current money. 
    #next time the function runs, it will use a new current money
    window.after(income_check_delay,income_check)
    #this function runs itself every 2.5 seconds


#this function is a general function to show the widgets
def show_widgets(widget_positions):
    for name, pos in widget_positions.items():
        if name in widgets:
            widgets[name].place(x=pos[0], y=pos[1])


#function to spawn all that is needed at the start of the game
def start_game():
    for widget in window.winfo_children():
        widget.place_forget()
        # Hide all main widgets except the menu
    spawn_dolla()
    income_check()  
    universal_update()
    #starts calling income check
    #allows for the dollar to start spawning
    #starts the universal checks
    menu_var.set('Clicker')
    #places all of the widgets in the clicker menu that are available



#function to check when a certain achievement has been reached
def achievement():
    global gambcount
    if Dc.achievement_flags[0]==False and Dc.money['money'] >= money_achievements[0]:
        Dc.achievement_flags[0]=True
        stats_page_dict['1st_ach'].configure(text="congrats on\n becoming a millionaire")
        stats_page_dict['1st_ach'].update()
        Dc.achievements+=1
        #checks if the achievement hasnt already been achieved and also that the requirements are met
        #if both are met, true achievement gets flagged as achieved and the the widget for the first achievement now congratulates you
        #finally this increases your total amount of achievements by 1

    if Dc.achievement_flags[1]==False and Dc.money['money'] >= money_achievements[1]:
        Dc.achievement_flags[1]=True
        widgets["2nd_ach"].configure(text="20 zeros is quite a lot")
        widgets["2nd_ach"].update()
        Dc.achievements+=1

    if Dc.achievement_flags[2]==False and Dc.money['money'] >= money_achievements[2]:
        Dc.achievement_flags[2]=True
        stats_page_dict['3rd_ach'].configure(text="wow 1 whole googol is crazy")
        stats_page_dict['3rd_ach'].update()
        Dc.achievements+=1

    if Dc.achievement_flags[3]==False and gambcount >= 30:
        Dc.achievement_flags[3]=True
        stats_page_dict['4th_ach'].configure(text="more likely to: \n win the lotterry")
        stats_page_dict['4th_ach'].update()
        Dc.achievements+=1

    if Dc.achievement_flags[4]==False and gambcount <= -20:
        Dc.achievement_flags[4]=True
        stats_page_dict['5th_ach'].configure(text="more likely to:\n get hit by lightning")
        stats_page_dict['5th_ach'].update()
        Dc.achievements+=1
        #this process is repeated for each achievement

#function for giving boosts to money gain after buying the respective upgrade
def upgrade(upgrade_type, index):
    #takes in an inputted type of upgrade - mpc or mps
    #also takes in a certain index for the upgrade
    group = None
    for data in Dc.upgrade_data:
        if data['type'] == upgrade_type:
            group = data
            break
        #checks through all upgrade data and if the typing matches
        #then it will set the group as the relevant data


    if group is None:
        return 
    #safety check
    #if data type doesnt match any of the data types available it exits immediately
    if upgrade_type == 'mpc':
        bought_list = Dc.upgrade_flags['click_bought']
    elif upgrade_type == 'mps':
        bought_list = Dc.upgrade_flags['auto_bought']
    #checks if the type is either mps or mpc
    #afterwards it sets bought_list as the list of booleans checking which upgrades are bought 
 
    else:
        return
    #if the upgrade type doesnt match with either mps or mpc, it exits immediately
    if bought_list[index]:
        return
    #if the upgrade shown by the index is already bought then it exist, ensuring the same upgrade cant be bough twice

    cost = group['costs'][index]
    #it sets cost as the cost of the upgrade
    
    if Dc.money['money'] < cost:
        return
    #if the player money is not enough, it exits immediately

    Dc.money['money'] -= cost
    #if the player has gotten to this point
    #the typing is correct and fits under mps or mpc
    #and the player has enough money to afford the upgrade
    #the exchange is made, taking away money

    multiplier = group['multipliers'][index]
    if upgrade_type == 'mpc':
        Dc.money_per_click['mpc_multiplier'] *= multiplier
        recalculate_mpc_mps('mpc')
    elif upgrade_type == 'mps':
        Dc.money_per_second['mps_multiplier'] *= multiplier
        recalculate_mpc_mps('mps')
    #it sets the variable multiplier as the boost tied to the upgrade
    #then depending on the upgrade type is boosts either mps or mpc multiplier
    #finally it recalculates mps or mpc based on which one got boosted

    bought_list[index] = True
    #it sets whichever upgrade has been done as bought.
    
    widget_name = group['widgets'][index]
    widgets[widget_name].place_forget()    
    #this deletes the button that is the tied to the upgrade



#function to spawn upgrades for money gained from clicks
def upgrade_check():
    global menu_var
    for upg in Dc.upgrade_definitions:
    #checks the definition of each upgrade
        if upg['type'] == 'mpc':
            current = Dc.money_per_click['mpc_count']
            active = Dc.upgrade_flags['click_active'][upg['index']]
            bought = Dc.upgrade_flags['click_bought'][upg['index']]
        
        elif upg['type'] == 'mps':
            current = Dc.money_per_second['mps_count']
            active = Dc.upgrade_flags['auto_active'][upg['index']]
            bought = Dc.upgrade_flags['auto_bought'][upg['index']]
        #sets the active condition and bought condition according to the upgrade that is being checked.
        #current is equal to the base mps or mpc at the time of the function running

        if current >= upg['count'] and not active and not bought and menu_var.get() == "Shop":
            if upg['type'] == 'mpc':
                Dc.upgrade_flags['click_active'][upg['index']] = True
                widgets[upg['widget']].place(x=600, y=300 + 150 * upg['index'])
            else:
                Dc.upgrade_flags['auto_active'][upg['index']] = True
                widgets[upg['widget']].place(x=750, y=300 + 150 * upg['index'])
        #checks if the current base mpc or mps surpasses the threshold needed to unlock the upgrade
        #then checks if the upgrade is not already out, has not been bought and the player is in the shop
        #if all conditions are met, it active as true to show it has been placed and then places the upgrade

        if menu_var.get() != "Shop" and active and not bought:
            if upg['type'] == 'mpc':
                Dc.upgrade_flags['click_active'][upg['index']] = False
                widgets[upg['widget']].place_forget()
            else:
                Dc.upgrade_flags['auto_active'][upg['index']] = False
                widgets[upg['widget']].place_forget()
        #this part of the function checks if the upgrade says its been placed but the player is not in the shop
        #if this has happened then it removes the respective button and unchecks the placed boolean so that it can be placed later


#function to change the size of the money bar to fit in the money count or change to a*10^n notation
def monlen():
    if len(str(int(Dc.money['money']))) < 7:
        clicker_dict['money'].configure(width=len(str(int(Dc.money['money'])))*26)
        clicker_dict['money'].update()
    else: 
        clicker_dict['money'].configure(width=160)
        clicker_dict['money'].update()
    #checks if the money is less than 1 million
    #if so, the money widget is configured to change its width to accomodate the amount of characters
    if menu_var.get()=="Clicker" :
        if Dc.money['money'] <= 10**6:
            clicker_dict['money'].place_forget()
            clicker_dict['money'].place(x=500-((len(str(int(Dc.money['money'])))*13)),y=175)
        else: 
            clicker_dict['money'].place_forget()
            clicker_dict['money'].place(x=500-78,y=175)
    #afterwards it checks if the player is in the clicker menu
    #if the player is, it places the clicker menu so that it is centered

#functions to deal with the realm
def realm_check(): 
    if menu_var.get() != "Shop" and Dc.realms['realm_placed']:
        Dc.realms['realm_placed'] = False
    #checks if the realm is placed and the player isnt in the shop
    #since the realm will be removed when changing menus the realm wont be there anymore
    #unchecks the realm placed boolean since the realm is no longer placed
    if not Dc.realms['realm_placed'] and Dc.money['peak_money']>=realm_base_threshold**(Dc.realms['record']+1) and menu_var.get() == "Shop":
        widgets['realm1'].place(x=100,y=500)
        Dc.realms['realm_placed'] = True
    #checks if the realm is not already placed
    #then checks if the players peak money has surpassed the threshold needed to unlock the portal
    #finally it checks if the player is in the shop menu
    #after all that, it places the portal and checks the boolean as true

def realm_change():
    menu_var.set('realm')
    #sets the current menu to the realm menu


#functions to deal with index based increases on money gain
def mpc_index():
    Dc.realms['mpc_power']+=index_power_increment
    Dc.realms['record']+=1
    menu_var.set("Shop")
    recalculate_mpc_mps('mpc')
    #the power that affects money per click is increased by 0.5
    #example 2^2 -> 2^2.5
    #afterwards it adds 1 to the amount of portals you have used 
    #this helps to calculate how expensive the next portal is
    #then it sets the menu to the shop 
    #finally it calculates money per click as it has increased

def mps_index():
    Dc.realms['record']+=1
    Dc.realms['mps_power']+=index_power_increment
    menu_var.set("Shop")
    recalculate_mpc_mps('mps')
    #basicallt the same function as the one before but it works with mps instead of mpc

#functions for the ascension system. ascension check works on calculating the milestone needed to reach the next ascension point. ascension world sets up the ascenion screen.
def ascension_check():
    while Dc.money['total_money_made']>=Dc.ascension['ascension_price']:
        Dc.ascension['ascension_total']+=1
        Dc.ascension['temp_ascension_points']+=1
        Dc.ascension['ascension_price']=(10**12)*(2**Dc.ascension['ascension_total'])
    #while the total money made is larger than the threshold for an excension point
    #the ascension total and temp points increase by 1 as well as calculating the new threshold

    clicker_dict['ascension'].configure(
        text=f"you have {Dc.ascension['temp_ascension_points']} ascension points available")
    clicker_dict['ascension'].update()
    #at the end it configures the ascension widget on the clicker menu to upgdate how many ascension points are available

def ascension_world():
    if Dc.ascension['ascension_points']> 0:
        menu_var.set('ascension')
        ascension += 1
        widgets["menu"].place_forget()
        ascension_dict['ascension_count'].configure(text=f"you have {Dc.ascension['ascension_points']} ascension points available")
        ascension_dict['ascension_count'].update()
    #if when you ascend there is at least 1 ascension point
    #it increases the total ascensions you ahve done
    #sends you to the ascension menu and shows how many points you have available to spend


    else:
        menu_var.set('Clicker')
    #if when you ascend you dont even have 1 ascension point
    #you just get sent back to the clicker 


#upgrade function for the ascension currency
def ascension_upgrades(n):
    if n==1 and Dc.ascension['ascension_mpc_upgrade_price']<=10:
        #checks if the upgrade is mpc and if the price is less than or equal to 10
        #the <= 10 matters because thats the price that the last upgrade is
        #if the upgrade costs more, there is no upgrade

        if Dc.ascension['ascension_points']>=Dc.ascension['ascension_mpc_upgrade_price']:
            #checks if you have enough points to buy the upgrade

            Dc.ascension['ascension_points']-=Dc.ascension['ascension_mpc_upgrade_price']
            Dc.ascension['ascension_mpc_upgrade']+=1
            Dc.ascension['ascension_mpc_upgrade_price']=Dc.ascension['ascension_mpc_upgrade']+1
            #exchanges your points for 1 stack of the ascension upgrade, then it recalculates how much the next upgrade should cost

            if Dc.ascension['ascension_mpc_upgrade'] < 10:
                ascension_dict['ascension upg1'].configure(text=f"you have {Dc.ascension['ascension_mpc_upgrade']} of this \n this will cost {Dc.ascension['ascension_mpc_upgrade_price']}\n this gives a {1+(Dc.ascension['ascension_mpc_upgrade']/5)}x boost to mpc")
                ascension_dict['ascension upg1'].update()
            #if the stacks of upgrade is less than 10, then it shows the stats of the upgrade

            if Dc.ascension['ascension_mpc_upgrade'] == 10:
                ascension_dict['ascension upg1'].configure(text=f"you have the\n max amount of this\n this gives a 3x boost to mpc")
                ascension_dict['ascension upg1'].update()
            #if the stacks of the upgrade are 10 then it shows that you have max stacks and shows total boost 
            
            recalculate_mpc_mps('mpc')
            #recalculates mpc as it has increased
    if n==2 and Dc.ascension['ascension_mps_upgrade_price']<=10:
        if Dc.ascension['ascension_points']>=Dc.ascension['ascension_mps_upgrade_price']:
            Dc.ascension['ascension_points']-=Dc.ascension['ascension_mps_upgrade_price']
            Dc.ascension['ascension_mps_upgrade']+=1
            Dc.ascension['ascension_mps_upgrade_price']=Dc.ascension['ascension_mps_upgrade']+1
            if Dc.ascension['ascension_mps_upgrade'] <= 10:
                ascension_dict['ascension upg2'].configure(text=f"you have {Dc.ascension['ascension_mps_upgrade']} of this \n this will cost {Dc.ascension['ascension_mps_upgrade_price']}\n this gives a {1+(Dc.ascension['ascension_mps_upgrade']/5)}x boost to mps")
                ascension_dict['ascension upg2'].update()
            if Dc.ascension['ascension_mps_upgrade'] == 10:
                ascension_dict['ascension upg2'].configure(text=f"you have the\n max amount of this\n this gives a 3x boost to mps")
                ascension_dict['ascension upg2'].update()            
            recalculate_mpc_mps('mps')
        #this is a copy of the first half of this function but instead it gives boosts to mps   
    ascension_dict['ascension_count'].configure(text=f"you have {Dc.ascension['ascension_points']} ascension points available")
    ascension_dict['ascension_count'].update()
    #upgrades the ascension point widget to show the new amount of ascension points you have

#functions similar to the ascension function but with research instead
def research_check():
    while Dc.money['total_money_made'] >= Dc.research['research_price']:
        Dc.research['research_total'] += 1
        Dc.research['temp_research_points'] += 1
        Dc.research['research_price'] = int((10**4)*(1.5**Dc.research['research_total']))

    clicker_dict['research_points'].configure(
        text=f"you have {Dc.research['temp_research_points']} research available")
    clicker_dict['research_points'].update()

def research_world():
    global rebirth
    if Dc.research['research_points']>0:
        menu_var.set('research_points')
        rebirth+=1
        widgets["menu"].place_forget()
        research_dict['research_count'].configure(text=f"you have {Dc.research['research_points']} research points available")
        research_dict['research_count'].update()
    else:
       menu_var.set('Clicker')   

#upgrade function for the research currency
def research_upgrades(n):
    if n==1 and Dc.research['research_mpc_upgrade_price']<=10:
        if Dc.research['research_points']>=Dc.research['research_mpc_upgrade_price']:
            Dc.research['research_points']-=Dc.research['research_mpc_upgrade_price']
            Dc.research['research_mpc_upgrade']+=1
            Dc.research['research_mpc_upgrade_price']=Dc.research['research_mpc_upgrade']+1
            if Dc.research['research_mpc_upgrade'] <= 10:
                research_dict['research upg1'].configure(text=f"you have {Dc.research['research_mpc_upgrade']} of this \n this will cost {Dc.research['research_mpc_upgrade_price']}\n this gives a {1+(Dc.research['research_mpc_upgrade']/10)}x boost to mpc")
                research_dict['research upg1'].update()
            if Dc.research['research_mpc_upgrade'] == 10:
                research_dict['research upg1'].configure(text=f"you have the\n max amount of this\n this gives a 2x boost to mpc")
                research_dict['research upg1'].update()
    if n==2 and Dc.research['research_mps_upgrade_price']<=10:
        if Dc.research['research_points']>=Dc.research['research_mps_upgrade_price']:
            Dc.research['research_points']-=Dc.research['research_mps_upgrade_price']
            Dc.research['research_mps_upgrade']+=1
            Dc.research['research_mps_upgrade_price']=Dc.research['research_mps_upgrade']+1
            if Dc.research['research_mps_upgrade'] <= 10:
                research_dict['research upg2'].configure(text=f"you have {Dc.research['research_mps_upgrade']} of this \n this will cost {Dc.research['research_mps_upgrade_price']}\n this gives a {1+(Dc.research['research_mps_upgrade']/10)}x boost to mps")
                research_dict['research upg2'].update()
            if Dc.research['research_mps_upgrade'] == 10:
                research_dict['research upg2'].configure(text=f"you have the\n max amount of this\n this gives a 2x boost to mps")
                research_dict['research upg2'].update()
    research_dict['research_count'].configure(text=f"you have {Dc.research['research_points']} research points available")
    research_dict['research_count'].update()
    recalculate_mpc_mps('mpc')
    recalculate_mpc_mps('mps')

#these 3 functions are just research versions of the ascension upgrade
#the values and names have changed but they are basically the same

#function to return from other realms
def returning(place):  
    menu_var.set(place)
    widgets["menu"].place(x=900,y=0)
#brings you back from whichever world you came from
#most likely ascension world,research world or caves.
#the returning place is based on input

#GAMBLING
def spin_roulette(colour,bet_amount):
    global gambcount
    if bet_amount <= 0 or Dc.money['money'] < bet_amount:
        roulette_dict['gambmount'].configure(text="Invalid bet")
        return
    #if the amount your betting is less than 0 or you dont have to bet then it shows "invalid bet"

    Dc.money['money']-= bet_amount
    #if youve gotten to this point then it will take away the bet amount from your current money

    result = random.randint(0,36)
    if roulette_options[colour]['check'](result):
        Dc.money['money'] += bet_amount * roulette_options[colour]['payout']
        gambcount+=1
    else:
        gambcount-=1
    #it randomly picks a number from 0-36
    #based on your input it will either give you money for your bet winning or just take your money for losing
    #gambcount is to show how many times youve won or lost in a row

    update_money_widget()
    #updates the money widget since money has decreased or increased based on your luck


#rebirth function - resets progress at the cost of gaining research points which help you reach the progress faster the next time - unlocks ascension on first succesful rebirth
def rebirthing():
    Dc.money['money']=0
    Dc.money_per_click['mpc'] = 1
    Dc.money_per_click['mpc_count'] = 1
    Dc.money_per_click['mpc_cost'] = 15
    Dc.money_per_click['mpc_multiplier'] = 1
    Dc.money_per_second['mps']= 0
    Dc.money_per_second['mps_cost'] = 100
    Dc.money_per_second['mps_multiplier'] = 1
    Dc.money_per_second['mps_count'] = 0
    Dc.upgrade_flags = {
    'click_active': [False,False,False,False],
    'click_bought': [False,False,False,False],
    'auto_active': [False,False,False,False],
    'auto_bought': [False,False,False,False],
    }
    #resets all upgrades, and all values to 0 
    #this is a proper reset

    widgets['rebirth_confirmation'].configure(text=f"confirm rebirth \n you will recieve {Dc.research['temp_research_points']} points")
    widgets['rebirth_confirmation'].update()
    #updates the rebirth confirmation to show how many points you will recieve

    Dc.research['research_points'] += Dc.research['temp_research_points']
    Dc.research['temp_research_points'] = 0    
    #adds how many points you should recieve and resets temp points
        
    recalculate_mpc_mps('mps')
    recalculate_mpc_mps('mpc')
    #recalculates mpc and mps since both have been reset
    
    research_world()
    #sends player to either the research area or the clicker area based on if you actually gained any points

#ascension function - similar to rebirth but also resets the rebirth values - unlocks world 2 upon first succesful ascension
def ascending():
    Dc.money['money']=0
    Dc.money_per_click['mpc'] = 1
    Dc.money_per_click['mpc_count'] = 1
    Dc.money_per_click['mpc_cost'] = 15
    Dc.money_per_click['mpc_multiplier'] = 1
    Dc.money_per_second['mps']= 0
    Dc.money_per_second['mps_cost'] = 100
    Dc.money_per_second['mps_multiplier'] = 1
    Dc.money_per_second['mps_count'] = 0
    Dc.research['temp_research_points'] = 0
    Dc.research['research_points'] = 0
    Dc.research['research_total'] = 0
    Dc.research['research_price'] = (10**4)
    Dc.research['research_mpc_upgrade']=0
    Dc.research['research_mps_upgrade']=0
    Dc.research['research_mpc_upgrade_price']=1
    Dc.research['research_mps_upgrade_price']=1
    Dc.upgrade_flags = {
    'click_active': [False,False,False,False],
    'click_bought': [False,False,False,False],
    'auto_active': [False,False,False,False],
    'auto_bought': [False,False,False,False],
    }
    widgets['ascension_confirmation'].configure(text=f"confirm ascension \n you will recieve {Dc.ascension['temp_ascension_points']} points")
    widgets['ascension_confirmation'].update()
    Dc.ascension['ascension_points'] += Dc.ascension['temp_ascension_points']
    Dc.ascension['temp_ascension_points'] = 0
    recalculate_mpc_mps('mps')
    recalculate_mpc_mps('mpc')    
    ascension_world()
    #similar function to the rebirth one
    #main difference is that it resets more stuff
    #also works with ascensions rather than research

menu_options = ["Clicker", "Shop","Stats_page","the casino"] 
#the main 4 menu options that should always be accesable in the first world


#function to switch from first and second world. current world = which world your currently in - makes sure your menu options are exclusive to the menus in that world
def world_shift():
    if Dc.world_stats['current_world'] == 1:
        #checks if the current world is world 1
        new_world = 2
        update_menu_options(world_2_menus)
        menu_var.set('A_clicker')
        #if the world is world 1 it sends you to the aether clicker (world 2 version of regular clicker)
        #it also changes the menu so that you can only go between the intended world 2 menu options
    elif Dc.world_stats['current_world'] == 2:
        new_world = 1
        update_menu_options(world_1_menus)
        menu_var.set('Clicker') 
        #basically the same as the first half but instead goes from 2->1
    Dc.world_stats['current_world']=new_world
    #sets the current world as the one youve changed into so 1->2 or 2->1


#aether version of the money_gain function for world 2
def aether_gain(m):
    Dc.aether['aether'] += m
    Dc.aether['total_aether_made'] += m    
    update_aether_widget()

#aether version of the upgrade_money_widget function which changes every time you gain aether
def update_aether_widget():
    display = format_money(Dc.aether['aether'])
    Aether_clicker_dict['aether'].configure(text=display)
    Aether_clicker_dict['aether'].update()
#these previous 2 wont be explained as they are copies of previous functions


#updates the menu options for when switching world - needed for world_shift
def update_menu_options(options):
    menu = widgets["menu"]["menu"]
    menu.delete(0, "end")
    #goes into the menu associated to the menu button and wipes it clean
    #0 is the first item, end is the final item so all items are removed
    #this ensures the menu has a clean slate

    for option in options:
    #checks through each item in the inputted list
        
        menu.add_command(
            label=option,
            #displays the name of the option
        
            command=lambda value=option: menu_var.set(value)
            #sets the function for what to do when the menu is set to this value
            #in this case it will set menu var as the option
        )   


#function to refresh the crystal screen while the player is there
def crystal_widget_update():
    caving_dictionary['crystal count'].configure(text=f"you have crystalised \n{int(Dc.crystalised['crystals'])} crystals\n your next crystal is in\n {(Dc.crystalised['growth_time'])-(Dc.crystalised['current_time'])}")
    if menu_var.get() == 'Crystal_caves':
        window.after(universal_delay,crystal_widget_update)
        #updates the crystal widgets
        #shows how long until the next crystal
        #actively updates how long is left and when the next crystal is made
        #updates every second as long as your still in the caves


#function to bring the player to the crystal caves
def caving():
    menu_var.set('Crystal_caves')   
    widgets["menu"].place_forget()
    crystal_widget_update()
    #removes the menu options
    #sets the menu as  the caves
    #starts the iterations of the crystal widget update

#function of when you trade crystals for boosts
def trading_crystals(n):
    if n==1:
        if Dc.crystalised['crystals'] < 2:
            pass
        else:
            Dc.events['crystal_boost'] = True
            Dc.crystalised['crystals'] -= 2
            window.after(10000,stop_crystal_boost)
    #basic exchange function
    #if n == 1 to show layout if you wanted to make more options for exchanging
    #checks if you have enough crystals, if not then it exits immediately
    #if you have enough, it activates the boost and takes away crystals
    #calls a function to stop the boost in 10 seconds

#function to stop the crystal boost after 10 seconds
def stop_crystal_boost():
    Dc.events['crystal_boost'] = False
    #sets the boost as false making it inactive


#creation of the menu
global menu_var
menu_var = tk.StringVar(window)
menu_var.set("Menu")

#images needed in the game and definition for size of 1 pixel
start_page = tk.PhotoImage(file="Assets/clicker game.png")
dollar = tk.PhotoImage(file="Assets/dollar.png")
click1 = tk.PhotoImage(file="Assets/click1.png")
click2 = tk.PhotoImage(file="Assets/click2.png")
click3 = tk.PhotoImage(file="Assets/click3.png")
click4 = tk.PhotoImage(file="Assets/click4.png")
auto1= tk.PhotoImage(file="Assets/auto1.png")
auto2= tk.PhotoImage(file="Assets/auto2.png")
auto3= tk.PhotoImage(file="Assets/auto3.png")
auto4= tk.PhotoImage(file="Assets/auto4.png")
warp= tk.PhotoImage(file="Assets/warp hole.png")

pixelVirtual = tk.PhotoImage(width=1, height=1)

#dictionary of widgets used in the ascension screen
ascension_dict = {
    'leg_bg' : tk.Label(window,height=1080,width=1920,background="#d88b1e",image=pixelVirtual),
    'ascension upg1': tk.Button(window,image=pixelVirtual,width=175,height=75,font=('Helvetica', 10),foreground="#000000",background="#C49D49",text=f"you have {Dc.ascension['ascension_mpc_upgrade']} of this \n this will cost {Dc.ascension['ascension_mpc_upgrade_price']}\n this gives a {1+(Dc.ascension['ascension_mpc_upgrade']/5)}x boost to mpc",compound="center",command=lambda:ascension_upgrades(1)),
    'ascension upg2': tk.Button(window,image=pixelVirtual,width=175,height=75,font=('Helvetica', 10),foreground="#000000",background="#C49D49",text=f"you have {Dc.ascension['ascension_mps_upgrade']} of this \n this will cost {Dc.ascension['ascension_mps_upgrade_price']}\n this gives a {1+(Dc.ascension['ascension_mps_upgrade']/5)}x boost to mps",compound="center",command=lambda:ascension_upgrades(2)),
    'ascension_count': tk.Label(window,image=pixelVirtual,width=300,height=75,font=('Helvetica', 10),foreground="#000000",background="#C49D49",text=f"you have {Dc.ascension['ascension_points']} points available to spend.",compound="center"),
    'research return': tk.Button(window,image=pixelVirtual,width=200,height=100,background="#8C8383",foreground="#000000",font=('Helvetica', 8),text="click to return",compound="center",command=lambda:returning("Clicker"))
}   

#dictionary of positions for the widgets in the ascension screen
ascension_dict_positions = {
    'leg_bg' : (0,0),
    'ascension upg1': (300,500),
    'ascension upg2': (600,500),
    'ascension_count': (400,100),
    'research return': (800,0)
}

#the next 100~ lines are in the same format of the ascension dictionaries. the main difference is that the clicker dictionary upgrades to have more widgets after first rebirth and ascension

research_dict = {
    'frame': tk.Frame(window,height=1080,width=1920,background="#1897BD"),    
    'research_count': tk.Label(window,image=pixelVirtual,width=300,height=75,font=('Helvetica', 10),foreground="#000000",background="#90AEF5",text=f"you have {Dc.research['research_points']} points available to spend.",compound="center"),
    'research upg1': tk.Button(window,image=pixelVirtual,width=175,height=75,font=('Helvetica', 10),foreground="#000000",background="#90AEF5",text=f"you have {Dc.research['research_mpc_upgrade']} of this \n this will cost {Dc.research['research_mpc_upgrade_price']}\n this gives a {1+(Dc.research['research_mpc_upgrade']/10)}x boost to mpc",compound="center",command=lambda:research_upgrades(1)),
    'research upg2': tk.Button(window,image=pixelVirtual,width=175,height=75,font=('Helvetica', 10),foreground="#000000",background="#90AEF5",text=f"you have {Dc.research['research_mps_upgrade']} of this \n this will cost {Dc.research['research_mps_upgrade_price']}\n this gives a {1+(Dc.research['research_mps_upgrade']/10)}x boost to mps",compound="center",command=lambda:research_upgrades(2)),
    'research return': tk.Button(window,image=pixelVirtual,width=200,height=100,background="#8C8383",foreground="#000000",font=('Helvetica', 8),text="click to return",compound="center",command=lambda:returning("Clicker")),

}

research_dict_positions = {
    'frame': ( 0, 0),
    'research_count': (400,100),
    'research upg1': (300,500),
    'research upg2': (600,500),
    'research return': (800,0)
}

clicker_dict = {
    'click' : tk.Button(window, height=50,width=200,image=pixelVirtual, borderwidth=10, background="#000000", command= lambda : money_gain(Dc.money_per_click['mpc'])),
    'money':tk.Label(window,image=pixelVirtual,height=50,width=len(str(Dc.money['money']))*26,text=Dc.money['money'],font=('Helvetica', 30),foreground="#000000",fg="#000000", background="#FFFFFF", compound='center'),
    'income': tk.Label(window, text= f"current average money per second is {int(Dc.money['income'])}",height=50,width=300,font=('Helvetica', 10),foreground="#000000",fg="#000000", background="#FFFFFF", compound='center',image=pixelVirtual),
    'research_points': tk.Button(window,image=pixelVirtual,width=250,height=50,font=('Helvetica', 10),foreground="#000000",background="#69789B",text=f"you have {Dc.research['temp_research_points']} research points available",compound="center",command=lambda:menu_var.set('rebirth confirmation')),
    'ascension' : None,
    'world_transfer' : None,
    'save_button' : tk.Button(window,image=pixelVirtual,width=200,height=100,text = "click to save data",foreground="#000000",background="#ffffff",compound='center',borderwidth=10,font=('Helvetica', 10),command=lambda:save_to_file()),
    'load_button' : tk.Button(window,image=pixelVirtual,width=200,height=100,text = "click to load data",foreground="#000000",background="#ffffff",compound='center',borderwidth=10,font=('Helvetica', 10),command=lambda:load_from_file())
}

clicker_dict_positions = {
    'click': (395, 100),
    'money': (500 - ((len(str(int(Dc.money['money']))) * 26) // 2), 175),
    'income': (360, 220),                
    'research_points':(0, 0),
    'ascension' : None,
    'world_transfer' : None,
    'save_button' : (400,500),
    'load_button' : (400,600)
}

Shop_dict = {
    'upgrades': tk.Label(window,image = pixelVirtual,height=1000,width=400,background="#878383",foreground="#000000"),
    'mps': tk.Button(window, height=50,width=200,image=pixelVirtual, borderwidth=10, background="#000000", command= lambda : buying_mps()),
    'mps_cost': tk.Label(window,image=pixelVirtual,height=50,width=400,text=f"you have {Dc.money_per_second['mps_count']} shop mps \n this current upgrade will cost {int(Dc.money_per_second['mps_cost'])}",font=('Helvetica', 10),foreground="#000000",fg="#000000", background="#FFFFFF", compound='center'),
    'mpc': tk.Button(window, text=Dc.money_per_click['mpc_cost'],image=pixelVirtual,height=50,width=200,borderwidth=10,font=('Helvetica',30),background="#000000", command= lambda :buying_mpc()),
    'mpc_cost':tk.Label(window,image=pixelVirtual,height=50,width=400,text=f"you have {Dc.money_per_click['mpc_count']} shop mpc \n this current upgrade will cost {int(Dc.money_per_click['mpc_cost'])}",font=('Helvetica', 10),foreground="#000000",fg="#000000", background="#FFFFFF", compound='center'),
    'shop money': tk.Label(window,image=pixelVirtual,width=200,height=75,background="#ffffff",foreground="#000000",text=f"you have {int(Dc.money['money'])} to spend",compound="center",font=('Helvetica', 10))
}

shop_dict_positions = {
    'upgrades': (600,0),
    'mps' : (600,175),
    'mps_cost' : (600,125),
    'mpc' : (600,50),
    'mpc_cost' : (600,00),
    'shop money' : (0,0)
}

caving_dictionary = {
    'caving bg' : tk.Frame(window,height=1000, width=1000,background="#aaaaaa"),
    'crystal count': tk.Label(window,image=pixelVirtual,width=200,height=150,background="#ffffff",foreground="#000000",text=f"you have crystalised \n{int(Dc.crystalised['crystals'])} crystals\n your next crystal is in\n {(Dc.crystalised['growth_time'])-(Dc.crystalised['current_time'])}",compound="center",font=('Helvetica', 10)),
    'caving return': tk.Button(window,image=pixelVirtual,width=200,height=100,background="#aaaaaa",foreground="#000000",font=('Helvetica', 8),text="click to return",compound="center",command=lambda:returning("Clicker")),
    'crystal_boost' : tk.Button(window,image=pixelVirtual,width=200,height=100,background="#aaaaaa",foreground="#000000",font=('Helvetica', 8),text="click to trade for a\n temporary boost",compound = 'center',command=lambda:trading_crystals(1)),
}

caving_dictionary_positions = {
    'caving bg' : (0,0),
    'crystal count': (0,0),
    'caving return': (800,0),
    'crystal_boost' : (200,500)
}

realm_dict = {
    'mpc_realm': tk.Button(window,image=pixelVirtual,width=200,height=100,font=('Helvetica', 10),foreground="#000000",background="#AE9F9F",text="click to incease click index",compound= "center",command=lambda:mpc_index()),
    'mps_realm': tk.Button(window,image=pixelVirtual,width=200,height=100,font=('Helvetica', 10),foreground="#000000",background="#AE9F9F",text="click to incease time index",compound= "center",command=lambda:mps_index())
}

realm_dict_positions = {
    'mpc_realm': (100,400),
    'mps_realm': (700,400)
}


widgets['frame'] = tk.Frame(window, height=1000, width=200, background="#000000")

stats_page_dict = {
    'button': tk.Button(window, text="hello", height=20, width=20, image=pixelVirtual, borderwidth=10, background="#000000", command = action),
    'frame': tk.Frame(window, height=1000, width=200, background="#000000"),
    'label':  tk.Label(widgets['frame'], text =f"Statistics:\nhighest money = {Dc.money['peak_money']}\ntotal money generated = {Dc.money['total_money_made']}\nmoney per second = {Dc.money_per_second['mps']}\nmoney per click = {Dc.money_per_click['mpc']}\ntime={Dc.time['hours']}:{Dc.time['minutes']}:{Dc.time['seconds']}\n achievements completed = {Dc.achievements}", foreground="#FFFFFF", background="#000000",font=('Helvetica', 10)),
    '1st_ach': tk.Label(window,image = pixelVirtual,height=100,width=200,background="#ffffff",foreground="#000000",text="achievement not achieved",compound = "center",font=('Helvetica', 10)),
    '2nd_ach':tk.Label(window,image = pixelVirtual,height=100,width=200,background="#ffffff",foreground="#000000",text="achievement not achieved",compound = "center",font=('Helvetica', 10)),
    '3rd_ach': tk.Label(window,image = pixelVirtual,height=100,width=200,background="#ffffff",foreground="#000000",text="achievement not achieved",compound = "center",font=('Helvetica', 10)),
    '4th_ach': tk.Label(window,image = pixelVirtual,height=100,width=200,background="#ffffff",foreground="#000000",text="achievement not achieved",compound = "center",font=('Helvetica', 10)),
    '5th_ach': tk.Label(window,image = pixelVirtual,height=100,width=200,background="#ffffff",foreground="#000000",text="achievement not achieved",compound = "center",font=('Helvetica', 10)),
    'crystal_cave': tk.Button(window,image = pixelVirtual,height=100,width=200,background="#ffffff",foreground="#000000",text="welcome to the caves",compound = "center",font=('Helvetica', 10), command=lambda:caving())
}

stats_page_dict_positions = {
    'button': (0,475),
    'frame': (-400,0),
    'label': (0,0),
    '1st_ach': (200,0),
    '2nd_ach': (400,0),
    '3rd_ach': (600,0),
    '4th_ach': (200,100),
    '5th_ach': (400,100),
    'crystal_cave' : (800,900)
}

roulette_dict = {
    'gambling background': tk.Label(window,height=1080,width=1920,background="#467F11",image =pixelVirtual),
    'all in on green': tk.Button(window,image=pixelVirtual,background = "#00ff00",foreground="#000000",width=200,height=100,
                                 font=('Helvetica', 10),compound='center',text = "click to spend  \ncurrent bet amount on green \nroll a 0 to win \n payout = 36x bet amount",
                                 command= lambda: spin_roulette('green',roulette_options['bet_amount'])),
    'all in on red': tk.Button(window,image=pixelVirtual,background = "#ff0000",foreground="#000000",width=200,height=100,
                               font=('Helvetica', 10),compound='center',text = "click to spend  \ncurrent bet amount on red \n get an odd number to win \n payout = 2x bet amount",
                               command= lambda: spin_roulette('red',roulette_options['bet_amount'])),
    'all in on black': tk.Button(window,image=pixelVirtual,background = "#000000",foreground="#ffffff",width=200,height=100,
                                 font=('Helvetica', 10),compound='center',text = "click to spend  \ncurrent bet amount on black \n get a non 0 even number to win \n payout = 2x bet amount",
                                 command= lambda: spin_roulette('black',roulette_options['bet_amount'])),
    'return to casino': tk.Button(window,image=pixelVirtual,width=200,height=100,background="#8C8383",foreground="#000000",font=('Helvetica', 10),text="click to return",compound="center",command=lambda:returning("the casino")),
    'gambmon': tk.Text(window,height=1,width=20,background="#ffffff",foreground="#000000",font=('Helvetica', 20)),
    'gambler set': tk.Button(window,image=pixelVirtual,height=100,width=100,background="#ffffff",foreground="#000000",compound="center",font=('Helvetica', 12),text="click to set new betting amount",command=lambda:checkifnumber()),
    'gambmount': tk.Label(window,image=pixelVirtual,height=75,width=225,background="#ffffff",foreground="#000000",font=('Helvetica', 12),compound="center",text=f"you are currently betting {roulette_options['bet_amount']}")

}


roulette_dict_positions = {
    'gambling background': (0,0),
    'all in on green': (400,500),
    'all in on red' : (200,500),
    'all in on black' : (600,500),
    'return to casino': (800,0),
    'gambmon': (300,100),
    'gambler set': (350,150),
    'gambmount' : (350,250)
}

Aether_clicker_dict = {
    'aether' : tk.Label(window,image=pixelVirtual,height=50,width=len(str(Dc.aether['aether']))*26,text=Dc.aether['aether'],font=('Helvetica', 30),foreground="#000000",fg="#000000", background="#FFFFFF", compound='center'),
    'aether_clicker' : tk.Button(window, height=50,width=200,image=pixelVirtual, borderwidth=10, background="#000000", command= lambda : aether_gain(Dc.aether_per_click['apc'])),
    'world_transfer' : tk.Button(window,image=pixelVirtual,text=f"???",background="#ffffff",foreground="#000000",borderwidth=10,font=('Helvetica',20),height=100,width=200,compound='center',command=world_shift)
}

Aether_clicker_dict_positions = {
    'aether' : (300,200),
    'aether_clicker': (300,400),
    'world_transfer' : (200,0)
}

#one time widgets that either - couldnt be put into a specific dictionary - dont have enough weight to require a dictionary - dont have enough relation to need a dictionary - easier outside of a dictionary
widgets["menu"] = tk.OptionMenu(window, menu_var ,*menu_options)
widgets["Start_page"] = tk.Label(window,image=start_page)
widgets["start_button"] = tk.Button(window,image=pixelVirtual,height=150,width=700,background="#000000",foreground="#ffffff",text="CLICK TO START",compound="center",font=('Helvetica', 60),command = lambda: start_game())
widgets['click 10'] = tk.Button(window,image=click1,command=lambda: upgrade("mpc",0))
widgets['click 25'] = tk.Button(window,image=click2,command=lambda: upgrade("mpc",1))
widgets['click 50'] = tk.Button(window,image=click3,command=lambda: upgrade("mpc",2))
widgets['click 100'] = tk.Button(window,image=click4,command=lambda: upgrade("mpc",3))
widgets['auto 10'] = tk.Button(window,image=auto1,command=lambda: upgrade("mps",0))
widgets['auto 25'] = tk.Button(window,image=auto2,command=lambda: upgrade("mps",1))
widgets['auto 50'] = tk.Button(window,image=auto3,command=lambda: upgrade("mps",2))
widgets['auto 100'] = tk.Button(window,image=auto4,command=lambda: upgrade("mps",3))
widgets["DOLLA"] = tk.Button(window,image=dollar,background="#000000",command=lambda: activate_capitalist_boost())
widgets['realm1'] = tk.Button(window,image=warp,command=lambda:realm_change())
widgets["roulette"] = tk.Button(window,image=pixelVirtual,text="roulette",background="#ffffff",foreground="#000000",borderwidth=10,font=('Helvetica', 30),height=50,width=200, compound='center',command = lambda:start_roulette())
widgets['rebirth_confirmation'] = tk.Button(window,image=pixelVirtual,text=f"confirm rebirth \n you will recieve {Dc.research['temp_research_points']} points",background="#ffffff",foreground="#000000",borderwidth=10,font=('Helvetica',20),height=100,width=400,compound='center',command= lambda:rebirthing())
widgets['ascension_confirmation'] = tk.Button(window,image=pixelVirtual,text=f"confirm ascension \n you will recieve {Dc.ascension['temp_ascension_points']} points",background="#ffffff",foreground="#000000",borderwidth=10,font=('Helvetica',20),height=100,width=400,compound='center',command= lambda:ascending())
widgets['world_transfer'] = tk.Button(window,image=pixelVirtual,text=f"???",background="#ffffff",foreground="#000000",borderwidth=10,font=('Helvetica',20),height=100,width=200,compound='center',command=world_shift)


#checks if the numebr inputted for the amount your gambling is in integer
def checkifnumber():
    x = roulette_dict['gambmon'].get("1.0","end").strip()

    try:
        value = int(x)

        if value <= 0:
            raise ValueError

        if value > Dc.money['money']:
            roulette_dict['gambmount'].configure(text="not enough money")
            return

        roulette_options['bet_amount'] = value
        roulette_dict['gambmount'].configure(
            text=f"you are currently betting {value}"
        )

    except ValueError:
        roulette_dict['gambmount'].configure(text="enter a valid number")


#function for changing menus
def change_menu(var, index, mode):
    # Hide all widgets first except menu
    for widget in window.winfo_children():
        widget.place_forget()
    widgets["menu"].place(x=900,y=0)
    upgrade_check()
        
    if menu_var.get() == "Shop":
        for item in Shop_dict:
            X,Y = shop_dict_positions[item]
            Shop_dict[item].place(x=X,y=Y)

    elif menu_var.get() == "Stats_page":
        for item in stats_page_dict:
            X,Y = stats_page_dict_positions[item]
            stats_page_dict[item].place(x=X,y=Y)

    elif menu_var.get() == "Clicker":
        for item in clicker_dict:
            widget = clicker_dict[item]
            if widget is not None:
                X,Y= clicker_dict_positions[item]
                widget.place(x=X,
                             y=Y
                )



    elif menu_var.get() == "the casino":

        clicker_dict['money'].place(x=0,y=0)
        show_widgets({
            'money': (0, 0),
            "roulette": (0, 50)
        })
        
    elif menu_var.get() == 'realm':
        for item in realm_dict:
            X,Y =realm_dict_positions[item]
            realm_dict[item].place(x=X,y=Y)

    elif menu_var.get() == 'ascension':
        for item in ascension_dict:
            X,Y = ascension_dict_positions[item]
            ascension_dict[item].place(x=X,y=Y)

    elif menu_var.get() == 'research_points':
        for item in research_dict:
            X,Y = research_dict_positions[item]
            research_dict[item].place(x=X,y=Y)

    elif menu_var.get() == 'roulette':
        clicker_dict['money'].place(x=400,y=0)
        for item in roulette_dict:
            X,Y = roulette_dict_positions[item]
            roulette_dict[item].place(x=X,y=Y)

    elif menu_var.get() == 'rebirth confirmation':
        widgets['rebirth_confirmation'].place(x=300,y=500)
        widgets["menu"].place_forget()

    elif menu_var.get() == 'ascension confirmation':
        widgets['ascension_confirmation'].place(x=300,y=500)
        widgets["menu"].place_forget()

    elif menu_var.get() == 'A_clicker':
        for item in Aether_clicker_dict:
            X,Y = Aether_clicker_dict_positions[item]
            Aether_clicker_dict[item].place(x=X,y=Y)

    elif menu_var.get() == 'Crystal_caves':
        for item in caving_dictionary:
            X,Y=caving_dictionary_positions[item]
            caving_dictionary[item].place(x=X,y=Y)

menu_var.trace_add('write', change_menu)

#start page
def starting():

    show_widgets({
        "Start_page": (0,0),
        "start_button": (150,700)
    })

#enters the roulette area of casino / roulette menu
def start_roulette():
    menu_var.set('roulette')
    widgets["menu"].place_forget()

#every second it updates the time count, gives money for mps, checks achievements, changes money widget to fit money size, checks if you can get another research check, and checks eligibility for realm access.
#once you rebirth once you also check for ascensions ever second
def universal_update():
    time_count()
    loop_amoney()
    achievement()
    monlen()
    realm_check()
    #research_check()
    if Dc.world_stats['rebirth'] == 1 and clicker_dict['ascension'] is None:
        clicker_dict_positions['ascension'] = {0,50}
        clicker_dict['ascension'] = tk.Button(window,image=pixelVirtual,width=250,height=50,font=('Helvetica', 10),foreground="#000000",background="#C49D49",text=f"you have {Dc.ascension['temp_ascension_points']} ascension points available",compound="center",command=lambda:menu_var.set('ascension confirmation'))
    if Dc.world_stats['rebirth'] > 0:
        ascension_check()
    if Dc.world_stats['ascension'] ==1 and clicker_dict['world_transfer'] is None:
        clicker_dict['world_transfer'] = tk.Button(window,image=pixelVirtual,text=f"???",background="#ffffff",foreground="#000000",borderwidth=10,font=('Helvetica',20),height=100,width=200,compound='center',command=world_shift)
        clicker_dict_positions['world_transfer'] = {200,0}
    window.after(universal_delay,universal_update)

if count==0:
    starting()

window.mainloop()    