#prices of each upgrade for mpc or mps when a certain mpc or mps count is reach
mpc_upgrade_costs = [250,10**4,10**7,2.5*(10**7)]
mpc_upgrade_multipliers = [2,20,50,100]
mps_upgrade_costs = [8000,2.5*(10**5),10**8,2.5*(10**10)]
mps_upgrade_multipliers = [25,25,50,100]


roulette_options = {
    'green': {'payout': 37, 'check': lambda x: x==37},
    'red': {'payout': 2, 'check': lambda x: x%2 == 0},
    'black': {'payout': 2, 'check': lambda x: x!=37 and(x+1)%2 ==0},
    'bet_amount':10
}

#global variables for upgrades, click/auto upgrade check to see if the the widget for the upgrade beem used yet (has the upgrade been bought yet)
# "click/upgrade_flags['auto_bought'][check" is used to check whether the upgrade option as appeared on the screen yet 
upgrade_flags = {
    'click_active': [False,False,False,False],
    'click_bought': [False,False,False,False],
    'auto_active': [False,False,False,False],
    'auto_bought': [False,False,False,False],
}
upgrade_definitions = [
    {'type': 'mpc', 'count': 10, 'widget': 'click 10', 'index' : 0},
    {'type': 'mpc', 'count': 25, 'widget': 'click 25', 'index' : 1 },
    {'type': 'mpc', 'count': 50, 'widget': 'click 50', 'index' : 2 },
    {'type': 'mpc', 'count': 100, 'widget': 'click 100','index': 3 },
    {'type': 'mps', 'count': 10, 'widget': 'auto 10','index' :  0 },
    {'type': 'mps', 'count': 25, 'widget': 'auto 25', 'index' : 1 },
    {'type': 'mps', 'count': 50, 'widget': 'auto 50', 'index' : 2 },
    {'type': 'mps', 'count': 100, 'widget': 'auto 100','index' : 3 }
    ]


upgrade_data= [
    {'type': 'mpc','costs': mpc_upgrade_costs, 'multipliers': mpc_upgrade_multipliers, 'widgets': ['click 10','click 25','click 50', 'click 100'], 'checks': [upgrade_flags['click_active'][0],upgrade_flags['click_active'][1],upgrade_flags['click_active'][2],upgrade_flags['click_active'][3]]},
    {'type': 'mps','costs': mps_upgrade_costs, 'multipliers': mps_upgrade_multipliers, 'widgets': ['auto 10','auto 25','auto 50', 'auto 100'], 'checks': [upgrade_flags['auto_active'][0],upgrade_flags['auto_active'][1],upgrade_flags['auto_active'][2],upgrade_flags['auto_active'][3]]}
    ]



#variables for whether achievements have been reached
achievements=0
achievement_flags=[False,False,False,False,False]

#variables needed for realm
realms = {
    'realm_placed' : False,
    'record':0,
    'mps_power': 1,
    'mpc_power': 1
}

#variables regarding the research section
research = {
    'research_total': 0,
    'research_price': (10**4),
    'research_points': 0,
    'temp_research_points': 0,
    'research_mpc_upgrade':0,
    'research_mps_upgrade':0,
    'research_mpc_upgrade_price':1,
    'research_mps_upgrade_price':1
}

#variables regarding the ascension section
ascension  = {
    'ascension_total' : 0,
    'ascension_price' : (10**12),
    'ascension_points' : 0,
    'temp_ascension_points': 0,
    'ascension_mpc_upgrade': 0,
    'ascension_mpc_upgrade_price': 1,
    'ascension_mps_upgrade': 0,
    'ascension_mps_upgrade_price' : 1
}

#money variables so income, money, total and peak
money = {
    'money': 0,
    'temp_money_1': 0,
    'income': 0,
    'peak_money': 0,
    'total_money_made':0
}

#variables to check for the dollar
events = {
    'dollar_count': 0,
    'capitalist': False
}

#time count
time = {
    'hours': 0,
    'minutes': 0,
    'seconds' : 0
}

#variables needed to calculate money per second and its costs
money_per_second = {
    'mps_count': 0,
    'mps': 0,
    'mps_cost': 100,
    'mps_multiplier': 1
}

#variables needed to calculate money per click and its costs
money_per_click = {
    'mpc': 1,
    'mpc_count':1,
    'mpc_cost':15,
    'mpc_multiplier':1,
}

#the second world variant of money
aether = {
    'aether' : 0,
    'temp_aether_1': 0,
    'income': 0,
    'peak_aether': 0,
    'total_aether_made':0
}

#same thing as money_per_click but world 2
aether_per_click = {
    'apc': 1,
    'apc_count':1,
    'apc_cost':100,
    'apc_multiplier':1,
}

#stats for the world such as rebirths done, ascensions done, which world your currently in
world_stats = {
    'current_world' :1,
    'rebirth' : 0,
    'ascension' : 0
    }